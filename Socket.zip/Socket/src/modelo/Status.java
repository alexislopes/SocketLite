package modelo;

public enum Status {
    OK, ERROR, PARAMERROR, SOLICITACAO, DIVZERO, SAIR
}
